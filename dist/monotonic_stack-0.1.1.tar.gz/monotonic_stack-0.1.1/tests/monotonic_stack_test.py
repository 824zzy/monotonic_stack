import monotonic_stack

ms = MonotonicStack([1, 2, 3, 4, 5])
print(ms.next_smaller_on_right())